package librairieControle;

public interface Comparable {
	void comparer(LivreAudio livreAudio);
}

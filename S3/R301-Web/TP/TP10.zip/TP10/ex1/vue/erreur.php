<?php
    echo "<p>cette entité n'existe pas";
?>
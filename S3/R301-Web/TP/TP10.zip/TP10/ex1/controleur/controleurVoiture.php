<?php

require_once("controleur.php");

class ControleurVoiture extends Controleur{
    protected static $objet = "voiture";
}

?>
<?php

require_once("controleur.php");

class ControleurUtilisateur extends Controleur{
    protected static $objet = "utilisateur";
}
?>
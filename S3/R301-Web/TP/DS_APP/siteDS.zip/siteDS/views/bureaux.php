<h1>Liste des Bureaux Disponibles</h1>
<ul>
    <?php
        echo "<p>Bureau</p><a href='routeur.php?controller=Bureaucontroller' class='button'>Reservations</a>";
    ?>
</ul>

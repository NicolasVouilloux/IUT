<?php
    foreach ($tab as $v) {
        $v->afficher();
    }
?>
<?php
    echo "<p>la voiture n'existe pas";
?>
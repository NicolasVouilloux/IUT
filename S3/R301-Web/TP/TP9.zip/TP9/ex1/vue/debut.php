<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $titre; ?></title>
	<link rel="stylesheet" href="../css/styleMenu.css">
	<link rel="stylesheet" href="../css/styleFooter.css">
	<link rel="stylesheet" href="../css/styleBoutons.css">
</head>
<body>

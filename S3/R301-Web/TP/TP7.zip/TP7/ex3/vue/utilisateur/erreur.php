<?php
    echo "<p>l'utilisateur n'existe pas";
?>
<?php
    foreach ($tab_u as $u) {
        $u->afficher();
    }
?>
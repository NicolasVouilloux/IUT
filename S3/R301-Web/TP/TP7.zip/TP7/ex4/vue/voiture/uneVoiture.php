<?php
    foreach ($tab_v as $v) {
        $v->afficher();
    }
?>
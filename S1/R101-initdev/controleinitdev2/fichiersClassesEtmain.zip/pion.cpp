#include "pion.h"

void  Pion::affiche()const{
  cout << "pion de couleur " << _couleur << endl;
}


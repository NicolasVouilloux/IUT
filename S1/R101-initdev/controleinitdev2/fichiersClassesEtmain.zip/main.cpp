#include "pion.h"
#include "combinaison.h"
#include <ctime>
#include <iostream>
using namespace std;

int main(){
  srand(time(NULL));  /// initialisation du tirage al�atoire (pour le constructeur de la classe Combinaison)
 
  
  return 0;
}

<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>CC2-EX3-types</title>
  </head>
  <body>
    <form action="notes.php" method="post">
    <div>
        <label for="typeMoy">Type moyenne</label>
        <input type="text" name="typeMoy" placeholder="ponderee ou simple">
    </div>
    <div>
        <label for="nb">nombres de notes</label>
        <input type="text" name="nb" placeholder="Votre nombre de notes">
    </div>
    </form>
  </body>
</html>
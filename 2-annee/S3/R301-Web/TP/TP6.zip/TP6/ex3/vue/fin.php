<footer>C'est mon site web et j'en suis fier</footer>
</body>
</html>
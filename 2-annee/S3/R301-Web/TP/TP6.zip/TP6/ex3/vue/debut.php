<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $titre; ?></title>
	<link rel="stylesheet" href="css/styleMenu.css">
</head>
<body>

<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>TP3 - ex3</title>
     
  </head>
  <body>
    <h2>Affichage de $_POST</h2>
    <?php
      echo "<pre>";
      print_r($_POST);
      echo "</pre>";
    ?>
    <a href="formulairePOST.html">retour au formulaire</a>
  </body>
</html>
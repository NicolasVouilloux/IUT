<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>TP3 - ex1</title>
     
  </head>
  <body>
    <h2>Affichage de $_GET</h2>
    <?php
      echo "<pre>";
      print_r($_GET);
      echo "</pre>";
    ?>
  </body>
</html>